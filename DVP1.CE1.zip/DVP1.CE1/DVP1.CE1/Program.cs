﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVP1.CE1
{
    class Program
    {
        static void Main(string[] args)
        {

            //NAME: Alexander Rodriguez
            //DATE: 1808
            //COURSE: Project & Portfolio 1
            //SYNOPSIS: Coding Challenges -Calling Menu from Main and select options to run each program.

            //Call Function Menu

            Menu.ChMenu();
        }
    }
}
